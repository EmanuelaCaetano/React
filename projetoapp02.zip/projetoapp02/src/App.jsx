// import React, { useState } from 'react'
// //pq não faz diferença com react ou sem


// import './App.css'

// function App() {
//   let time = new Date().toLocaleTimeString();

//   const [ctime, setCtime] = useState(time);

//   const updateTime = () => {
//     time = new Date().toLocateTimeString();
//     setCtime(time);
//   };

//   setInterval(updateTime, 1000);

//   return (
//     <>
//     <h2>Timer</h2>
//     <h1> {ctime} </h1>
//     </>
//   )
// }

// export default App

import React, { useState } from 'react'
//pq não faz diferença com react ou sem


import './App.css'

const App = () => {
  let time = new Date().toLocaleTimeString();

  const [ctime, setCtime] = useState(time);

  const updateTime = () => {
    time = new Date().toLocaleTimeString();
    setCtime(time);
  };

  setInterval(updateTime, 1000);

  return (
    <>
    <h2>Timer</h2>
    <h1> {ctime} </h1>
    </>
  )
}

export default App

