import { useState } from 'react'
import './App.css'

function App() {
  const [value, setValue] = useState(0)
  

  return (
  
      <>
       <div>
        <p className='value'>{value}</p>
        <h1>
          simple react counter
        </h1>
        <button className='btn' onClick={() => setValue(value + 1)}>incremento</button>
        <button className='btn' onClick={() => setValue(value - 1)}>decremento</button>
       </div><button className='btn' onClick={() => setValue(0)}>reiniciar</button>
    </>
  )
}

export default App
