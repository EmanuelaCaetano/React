function Header() {
    const name = 'manu'
    console.log("chamou")
    return(
        <div>
            <h1> lojinha da manulita</h1>
        </div>
    )
}
export default Header